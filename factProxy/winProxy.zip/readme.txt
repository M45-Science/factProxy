1: Launch program

2: Option A:
Open connect-links.html

2: Option B:
In factorio connect to 127.0.0.1:20000 (server a)
20001 (server b)
... etc
