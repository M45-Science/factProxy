1: Launch program
2: In factorio conenct to 127.0.0.1:20000 (server a)

20001 (server b)
... etc
